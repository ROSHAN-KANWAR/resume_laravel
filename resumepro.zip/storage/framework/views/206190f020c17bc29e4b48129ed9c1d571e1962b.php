<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 sidebar  text-center">
            <img src="<?php echo e(asset('photos/avt-img.jpg')); ?>" alt="" class="mt-4 img-thumbnail img-fluid rounded-circle">
  <div class="nav flex-column  mt-5">
      <a href="<?php echo e(route('home')); ?>" class=" nav-link <?php echo e(Request::routeIs('home') ? 'active' : ""); ?>">Home</a>
      <a href="<?php echo e(route('skill')); ?>" class=" nav-link <?php echo e(Request::routeIs('skill') ? 'active' : ""); ?>">Skill</a>
      <a href="<?php echo e(route('service')); ?>" class=" nav-link <?php echo e(Request::routeIs('service') ? 'active' : ""); ?>">Service</a>
      <a href="<?php echo e(route('contact')); ?>" class=" nav-link <?php echo e(Request::routeIs('contact') ? 'active' : ""); ?>">Contact</a>
  </div>
        </div>
        <div class="col-md-10">
            <?php echo $__env->yieldContent('main-section'); ?>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;<?php /**PATH C:\xampp\htdocs\resumepro\resources\views/layouts/main.blade.php ENDPATH**/ ?>