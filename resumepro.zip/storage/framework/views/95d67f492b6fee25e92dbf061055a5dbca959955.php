
<?php $__env->startSection('titlepage'); ?>
<title>Welcome Serive page</title>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-section'); ?>
<div class="container mt-5">
    <h2 class="text-warning mb-5 border-bottom">Service</h2>
    <div class="row text-white text-center mb-5">
        <div class="col-sm-4">
            <i class="fas fa-search-dollar fa-2x mb-3 i-color"></i>
            <h3>SEO</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
        <div class="col-sm-4">
            <i class="fas fa-palette fa-2x mb-3 i-color"></i>
            <h3>Web Design</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
        <div class="col-sm-4">
            <i class="fas fa-code fa-2x mb-3 i-color"></i>
            <h3>Web Development</h3>
            <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
    </div>
    <div class="row text-white text-center mb-5">
        <div class="col-sm-4">
            <i class="fas fa-apple-alt fa-2x mb-3 i-color"></i>
            <h3>iSO</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
        <div class="col-sm-4">
            <i class="fab fa-android fa-2x mb-3 i-color"></i>
            <h3>Android</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
        <div class="col-sm-4">
            <i class="fas fa-ad  fa-2x mb-3 i-color"></i>
            <h3>Advertising</h3>
            <p class="ss-color">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
    </div>
    <div class="row text-white text-center mb-5">
        <div class="col-sm-4">
            <i class="fas fa-pencil-alt fa-2x mb-3 i-color"></i>
            <h3>Logo Design</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
        <div class="col-sm-4">
            <i class="fas fa-database fa-2x mb-3 i-color"></i>
            <h3>Hosting</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>
        <div class="col-sm-4">
            <i class="fas fa-headset fa-2x mb-3 i-color"></i>
            <h3>Support</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos, exercitationem?</p>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resumepro\resources\views/service.blade.php ENDPATH**/ ?>