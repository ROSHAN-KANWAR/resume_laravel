<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Servicepage extends Controller
{
    public function Servicepage(){
        return view('service');
    }   
}
