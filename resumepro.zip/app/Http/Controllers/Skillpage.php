<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Skillpage extends Controller
{
    public function Skillpage(){
        return view('skill');
    }
}
