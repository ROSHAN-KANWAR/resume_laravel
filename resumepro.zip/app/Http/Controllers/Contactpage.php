<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Contactpage extends Controller
{
    public function Contactpage(){
        return view('contact');
    }
}
